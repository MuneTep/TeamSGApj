// Copyright Epic Games, Inc. All Rights Reserved.

#include "SGA_Teamprj.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SGA_Teamprj, "SGA_Teamprj" );
